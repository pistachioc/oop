public class BankException extends java.lang.Exception {
    
    /**
     * Constructor.
     */
    public BankException(String message) {
        super(message);
    }
}
