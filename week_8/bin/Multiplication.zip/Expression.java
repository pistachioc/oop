public abstract class Expression {

    /**
     * evaluate.
     */
    public abstract double evaluate();

    /**
     * toString.
     */
    public abstract String toString();
}
